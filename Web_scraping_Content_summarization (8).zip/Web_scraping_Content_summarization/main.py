import re
import requests


# Function to extract the title from a given link using regular expressions
def extract_title_from_link(link):
    try:
        response = requests.get(link)
        html_content = response.text

        # Regular expression pattern to match the title tag
        title_pattern = re.compile(r"<title>(.*?)</title>", re.IGNORECASE | re.DOTALL)
        match = title_pattern.search(html_content)

        if match:
            title = match.group(1).strip()
            return title
        else:
            return None
    except requests.RequestException as e:
        print(f"Error fetching {link}: {e}")
        return None


# Example link
link = "https://en.wikipedia.org/wiki/Iris_flower_data_set"

# Extract title using regular expressions
title = extract_title_from_link(link)
if title:
    print(f"Title of the page: {title}")
