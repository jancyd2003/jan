import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


# Step 1: Extract links from a website
def extract_links(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")
    links = []
    for a_tag in soup.find_all("a", href=True):
        # Convert relative URLs to absolute URLs
        full_url = urljoin(url, a_tag["href"])
        links.append(full_url)
    return links


# Step 2: Extract contents from each link
def extract_content_from_link(link):
    try:
        response = requests.get(link)
        soup = BeautifulSoup(response.text, "html.parser")
        # Extract content; here we extract text inside <p> tags as an example
        content = " ".join([p.text for p in soup.find_all("p")])
        return content
    except requests.RequestException as e:
        print(f"Error fetching {link}: {e}")
        return None


# # Example usage
# url = "https://en.wikipedia.org/wiki/Iris_flower_data_set"  # Replace with the website you want to scrape

# # Extract links
# links = extract_links(url)
# print(f"Found {len(links)} links")

# # Extract contents from each link
# contents = []
# for link in links[:10]:
#     content = extract_content_from_link(link)
#     if content:
#         contents.append(content)

# # Print the extracted contents
# for i, content in enumerate(contents, 1):
#     print(
#         f"Content from link {i}:\n{content[:500]}..."
#     )  # Print first 200 characters of the content


import re
import requests


# Function to extract the title from a given link using regular expressions
def extract_title_from_link(link):
    try:
        response = requests.get(link)
        html_content = response.text

        # Regular expression pattern to match the title tag
        title_pattern = re.compile(r"<title>(.*?)</title>", re.IGNORECASE | re.DOTALL)
        match = title_pattern.search(html_content)

        if match:
            title = match.group(1).strip()
            return title
        else:
            return None
    except requests.RequestException as e:
        print(f"Error fetching {link}: {e}")
        return None


# # Example link
# link = "https://en.wikipedia.org/wiki/Iris_flower_data_set"

# # Extract title using regular expressions
# title = extract_title_from_link(link)
# if title:
#     print(f"Title of the page: {title}")
