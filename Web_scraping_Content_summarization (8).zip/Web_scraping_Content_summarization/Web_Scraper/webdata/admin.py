from django.contrib import admin
from .models import WebContent
# Register your models here.

admin.site.register(WebContent)