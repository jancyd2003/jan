from django.db import models

# Create your models here.


class WebContent(models.Model):
    site_title = models.CharField(max_length=80, help_text="scraped website title")
    content_title = models.CharField(
        max_length=80, help_text="scraped content title", null=True
    )
    content = models.TextField(null=True)
