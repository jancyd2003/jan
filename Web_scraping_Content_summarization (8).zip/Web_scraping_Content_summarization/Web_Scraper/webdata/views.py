from django.shortcuts import render
from django.http import HttpResponse
from .models import WebContent
from django.views.decorators.csrf import csrf_exempt
from .web_scraper import extract_links, extract_title_from_link
import json


# Create your views here.
def index(request):
    return HttpResponse("<h1>this is the index page of django project</h1>")


def link_getter(request):
    return render(request, "link_get.html")


def scraped_data(request):

    scrap_content = WebContent.objects.all()
    return render(request, "index.html", {"scraped_data": scrap_content})


@csrf_exempt
def scrape_data(request):
    if request.method == "POST":
        main_link = request.POST.get("link")

        no_of_links = extract_links(main_link)

        title = extract_title_from_link(main_link)
        # storing the scraped the content
        WebContent.objects.create(
            site_title=title,
            content_title=f"list of links found in the given link {main_link}",
            content=no_of_links,
        )
        return HttpResponse(f"inserted link is : {main_link}")
